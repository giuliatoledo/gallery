# galeria-thumbnail
Para uso em atividade em sala.
