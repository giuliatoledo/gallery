<?php
class Galeria{
    public $id;
    public $nome;
    public $descricao;
}