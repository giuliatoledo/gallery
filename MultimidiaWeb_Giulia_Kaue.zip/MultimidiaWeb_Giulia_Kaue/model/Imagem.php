<?php

class Imagem{
    public $id;
    public $descricao;
    public $data;
    public $arquivo;
    public $galeria_id;

}